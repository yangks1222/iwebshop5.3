<?php
return array(
	'name'    => '锦绣前程-黑色皮肤',
	'author'  => 'aircheng',
	'time'    => '2013-11-10',
	'version' => '4.7',
	'thumb'   => 'preview.jpg',
	'info'    => 'aircheng旗下，IwebShop产品锦绣前程首款默认皮肤方案',
);
?>