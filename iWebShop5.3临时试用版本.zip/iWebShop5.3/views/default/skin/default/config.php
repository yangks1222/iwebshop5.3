<?php
return array(
	'name'    => '锦绣前程-橙色皮肤',
	'author'  => 'aircheng',
	'time'    => '2011-01-01',
	'version' => '4.7',
	'thumb'   => 'preview.jpg',
	'info'    => 'aircheng旗下，IwebShop产品锦绣前程首款默认皮肤方案',
);
?>