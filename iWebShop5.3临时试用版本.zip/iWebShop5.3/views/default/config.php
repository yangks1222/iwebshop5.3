<?php
return array(
	'name'    => '锦绣前程',
	'author'  => 'aircheng',
	'time'    => '2014/12/29 10:03:05',
	'version' => '4.7',
	'thumb'   => 'preview.jpg',
	'info'    => 'aircheng旗下，IwebShop产品首款默认主题方案，此主题适用于IwebShop4.5+系列产品',
	'type'    => '商城前台-PC',
	'ad'      => array(
		"页面顶部通栏广告条960*70(default)",
		"首页中部通栏960*70(default)",
		"首页右上方198*104(default)",
		"文章-公告内容页左册198*120(default)",
		"商品搜索结果页左侧198*120(default)",
	),
);