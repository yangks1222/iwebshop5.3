<?php
/**
 * @copyright (c) 2011 aircheng.com
 * @file market.php
 * @brief 营销模块
 * @author nswe
 * @date 2018/4/17 8:42:44
 * @version 5.1
 */
class APIMarket
{

}